<?php
include 'db.php';
include 'header.php';
if (!isset($_SESSION['user_id']) || $_SESSION['role_id'] != 10) {
    header("Location: signin.php");
    exit;
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
</head>
<body>
    
    <h1>This is the admin dashboard.</h1>

</body>
</html>
<?php include 'footer.php';?>