<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: signin.php");
    exit;
}

include 'db.php'; // Database connection

$query = "
    SELECT o.order_id, u.name, o.total_price, o.order_date, o.status 
    FROM orders o
    JOIN users u ON o.user_id = u.user_id";
$result = $conn->query($query);

while ($row = $result->fetch_assoc()) {
    echo "
    <div>
        <h3>Order ID: {$row['order_id']}</h3>
        <p>User: {$row['name']}</p>
        <p>Total Price: {$row['total_price']}</p>
        <p>Status: {$row['status']}</p>
        <form method='POST' action='update_order_status.php'>
            <input type='hidden' name='order_id' value='{$row['order_id']}'>
            <select name='status'>
                <option value='pending' " . ($row['status'] == 'pending' ? 'selected' : '') . ">Pending</option>
                <option value='completed' " . ($row['status'] == 'completed' ? 'selected' : '') . ">Completed</option>
            </select>
            <button type='submit'>Update Status</button>
        </form>
    </div>";
}
?>