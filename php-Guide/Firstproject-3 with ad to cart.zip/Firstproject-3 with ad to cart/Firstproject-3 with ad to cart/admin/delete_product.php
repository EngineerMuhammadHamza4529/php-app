<?php

include("db.php");

if(isset($_GET['product_id']))
{
    $product_id = $_GET['product_id'];

    $sql = "Delete from products
    where product_id = $product_id";

    if(mysqli_query($conn, $sql))
    {
        echo "<script>alert('Product Delated successfully!'); window.location.href = 'view_product.php';</script>";
    }
    else{
        echo "product Not found ";
    }
}
?>