<?php
include("db.php");
include("header.php");


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $p_name = $_POST['pname'];
    $p_price = $_POST['pprice'];
    $p_quantity = $_POST['quantity'];
    $category = $_POST['category'];

  
    $file_name = $_FILES['image']['name'];
    $file_tmp = $_FILES['image']['tmp_name'];
    $file_type = $_FILES['image']['type'];
    $file_size = $_FILES['image']['size'];

    
    $upload_dir = "uploads-images/";

   
    if (!empty($file_name)) {
      
        if (move_uploaded_file($file_tmp , $upload_dir . $file_name)) {
    
            $sql = "INSERT INTO `products`(`product_name`, `price`, `quantity`, `product_image`, `category_id`) 
            VALUES ('$p_name','$p_price','$p_quantity','$file_name','$category')";

            if (mysqli_query($conn, $sql))
            {
                echo "<script>alert('Product added successfully!'); window.location.href = 'view_product.php';</script>";
            } 
            else 
            {
                echo "Error: " . $sql . "<br>" . mysqli_error($conn);
            }
            mysqli_close($conn);
        }
         
    }
}
?>




 <!-- Form Start -->
 <div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                    <div class="col-sm-12 col-xl-6">
                        <div class="bg-light rounded h-100 p-4">
                            <h6 class="mb-4">Add Product</h6>
                            <form action="#" method="post" enctype="multipart/form-data">
                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Product Name</label>
                                    <input type="text" name="pname" class="form-control" id="exampleInputEmail1"
                                        aria-describedby="emailHelp">
                                </div>
                                <div class="mb-3">
                                    <label for="exampleInputPassword1" class="form-label">Price</label>
                                    <input type="text" name="pprice" class="form-control" id="exampleInputPassword1">
                                </div>
                                <div class="mb-3">
                                    <label for="exampleInputPassword1" class="form-label">Quantity</label>
                                    <input type="text" name="quantity" class="form-control" id="exampleInputPassword1">
                                </div>
                                <div class="mb-3">
                                <label for="exampleInputPassword1" class="form-label">Product Image</label>
                                    <input type="file" name="image" class="form-control" id="exampleInputPassword1">
                                </div>
                                <div class="form-group">  
                                    <label for="category">Select Categories:</label>
                                    <select class="form-control" id="category" name="category" required>
                                        <?php
                                        $sql = "SELECT category_id, category_name FROM categories";
                                        $result = mysqli_query($conn, $sql);
                                        if ($result && mysqli_num_rows($result) > 0) {
                                            while ($row = mysqli_fetch_assoc($result)) 
                                            {
                                                echo "<option value='" . $row['category_id'] . "'>" . $row['category_name'] . "</option>";
                                            }
                                        } else {
                                            echo "<option value=''>No categories available</option>";
                                        }
                                        ?>
                                    </select>
                                </div>
                                <BR>
                                <div class="mb-3 form-check">
                                    <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                    <label class="form-check-label" for="exampleCheck1">Check me out</label>
                                </div>
                                <BR>
                                <button type="submit" class="btn btn-primary">Add Product</button>
                            </form>
                        </div>
                    </div>
                  
                </div>
            </div>
            <!-- Form End -->



<?php

include("footer.php");
?>