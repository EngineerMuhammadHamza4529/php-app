<?php

include 'header.php';


?>

<h1> Admin Dashboard</h1>
    


  


        


       



<?php
    include("footer.php");
?>