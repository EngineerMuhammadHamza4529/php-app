<?php

include("db.php");

if(isset($_GET['category_id']))
{
    $category_id = $_GET['category_id'];

    $sql = "Delete from categories
    where category_id = $category_id";

    if(mysqli_query($conn, $sql))
    {
        echo "Category deleted sucessfully";
    }
    else{
        echo "Category Not found ";
    }
}
?>