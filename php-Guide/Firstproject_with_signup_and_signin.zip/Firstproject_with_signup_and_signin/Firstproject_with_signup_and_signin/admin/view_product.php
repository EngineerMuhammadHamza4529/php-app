<?php
include("db.php");
include("header.php");

?>



 <!-- Table Start -->
 <div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                    <div class="col-sm-12 col-xl-6">
                        <div class="bg-light rounded h-100 p-4">
                            <h6 class="mb-4">Basic Table</h6>
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th scope="col">Produc ID</th>
                                        <th scope="col">Product Name</th>
                                        <th scope="col">Price</th>
                                        <th scope="col">Quantity</th>
                                        <th scope="col">Product Image</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <?php 
                    
                    $sql = "SELECT * FROM products";
                    
                    $result = mysqli_query($conn, $sql);
                    
                    if(mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            ?>
                <tr>
                    <td><?php echo $row['product_id']; ?></td>
                    <td><?php echo $row['product_name']; ?></td>
                    <td><?php echo $row['price']; ?></td>
                    <td><?php echo $row['quantity']; ?></td>
                    
                    <td>
                        <!-- Corrected Image Tag -->
                        <img src="uploads-images/<?php echo $row['product_image']; ?>" alt="fan" style="width: 50%; height: 50%;">
                    </td>

                    <td>
                        <a href="edit_product.php?product_id=<?php echo $row['product_id']; ?>">Edit</a>
                        <a href="delete_product.php?product_id=<?php echo $row['product_id']; ?>">Delete</a>
                    </td>
                </tr>

                 <?php
                    }
                    }
                    else
                    {
                    
                    echo "<tr><td colspan='4'>No products found</td></tr>";
                    }
                    ?>
              </tbody>
           </table>
        </div>
     </div>
  </div>
</div>




<?php

include("footer.php");
?>