<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: signin.php");
    exit;
}

include 'db.php'; // Database connection

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $order_id = $_POST['order_id'];
    $status = $_POST['status'];

    $query = "UPDATE orders SET status = ? WHERE order_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("si", $status, $order_id);
    $stmt->execute();

    header("Location: admin_orders.php"); // Redirect back to orders page
}
?>