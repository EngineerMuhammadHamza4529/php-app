<?php
include('header.php');
include('db.php');
?>

<p><?php echo $_SESSION['name']?></p>
<?php
include('footer.php');
?>