<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: signin.php");
    exit;
}

include 'db.php'; // Database connection

$user_id = $_SESSION['user_id'];

// Get the total price from the cart
$query = "
    SELECT SUM(p.price * c.quantity) AS total_price
    FROM cart c 
    JOIN products p ON c.product_id = p.product_id 
    WHERE c.user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$total_price = $row['total_price'];

echo "<h3>Total Price: $total_price</h3>";

echo "
    <form method='POST' action='place_order.php'>
        <button type='submit'>Place Order</button>
    </form>";
?>