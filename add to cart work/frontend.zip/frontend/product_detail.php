<?php 

include '../admin/db.php';
include 'header.php'; 

if (isset($_GET['product_id'])) {
    $product_id = $_GET['product_id'];

    // Secure query using prepared statements
    $query = "
        SELECT p.product_id, p.product_name, p.price, p.quantity, p.product_image, c.category_description
        FROM products p
        INNER JOIN categories c ON p.category_id = c.category_id
        WHERE p.product_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
    } else {
        echo "<div class='alert alert-danger text-center'>Product not found.</div>";
        exit();
    }
} else {
    echo "<div class='alert alert-danger text-center'>Product ID not specified.</div>";
    exit();
}

mysqli_close($conn);
?>

<div class="container-xxl py-5">
    <div class="container">
        <div class="row g-5 align-items-center">
            <div class="col-lg-6 wow fadeIn" data-wow-delay="0.1s">
                <div class="about-img position-relative overflow-hidden p-5 pe-0">
                    <img class="img-fluid w-100" src="../admin/uploads-images/<?php echo htmlspecialchars($row['product_image']); ?>" alt="<?php echo htmlspecialchars($row['product_name']); ?>">
                </div>
            </div>
            <div class="col-lg-6 wow fadeIn" data-wow-delay="0.5s">
                <h1 class="display-5 mb-4"><?php echo htmlspecialchars($row['product_name']); ?></h1>
                <p class="mb-4"><?php echo htmlspecialchars($row['category_description']); ?></p>
                <p><i class="fa fa-check text-primary me-3"></i>Price: $<?php echo htmlspecialchars($row['price']); ?></p>
                <p><i class="fa fa-check text-primary me-3"></i>Available Quantity: <?php echo htmlspecialchars($row['quantity']); ?></p>
                <?php if ($row['quantity'] > 0): ?>
                    <form action="add_to_cart.php" method="POST">
                        <input type="hidden" name="product_id" value="<?php echo $row['product_id']; ?>">
                        <input type="number" name="quantity" class="form-control mb-3" min="1" max="<?php echo $row['quantity']; ?>" value="1" required>
                        <button type="submit" class="btn btn-success">Add to Cart</button>
                    </form>
                <?php else: ?>
                    <button class="btn btn-danger" disabled>Out of Stock</button>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
