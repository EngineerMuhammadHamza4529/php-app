<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: signin.php");
    exit;
}

include 'db.php'; // Database connection

$user_id = $_SESSION['user_id'];

// Get the total price from the cart
$query = "
    SELECT SUM(p.price * c.quantity) AS total_price
    FROM cart c 
    JOIN products p ON c.product_id = p.product_id 
    WHERE c.user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$total_price = $row['total_price'];

// Insert the order into the orders table
$query = "INSERT INTO orders (user_id, total_price) VALUES (?, ?)";
$stmt = $conn->prepare($query);
$stmt->bind_param("id", $user_id, $total_price);
$stmt->execute();

// Get the order ID
$order_id = $stmt->insert_id;

// Clear the user's cart
$query = "DELETE FROM cart WHERE user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();

echo "<h3>Your order has been placed successfully!</h3>";
?>