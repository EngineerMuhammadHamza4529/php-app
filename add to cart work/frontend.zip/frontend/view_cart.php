<?php
include 'header.php'; // Includes session handling and navigation
include '../admin/db.php'; // Database connection

$user_id = $_SESSION['user_id']; // User ID is already set in the session

$query = "
    SELECT c.cart_id, p.product_name, p.price, c.quantity 
    FROM cart c 
    JOIN products p ON c.product_id = p.product_id 
    WHERE c.user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$total_price = 0;
?>

<div class="container py-5">
    <h2 class="mb-4">Your Cart</h2>
    <?php if ($result->num_rows > 0): ?>
        <div class="row">
            <?php while ($row = $result->fetch_assoc()): 
                $item_total = $row['price'] * $row['quantity'];
                $total_price += $item_total;
            ?>
                <div class="col-md-6 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo htmlspecialchars($row['product_name']); ?></h5>
                            <p class="card-text">Price: $<?php echo number_format($row['price'], 2); ?></p>
                            <p class="card-text">Quantity: <?php echo htmlspecialchars($row['quantity']); ?></p>
                            <p class="card-text text-success">Total: $<?php echo number_format($item_total, 2); ?></p>
                            <form method="POST" action="remove_form_cart.php">
                                <input type="hidden" name="cart_id" value="<?php echo $row['cart_id']; ?>">
                                <button type="submit" class="btn btn-danger btn-sm">Remove</button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
        <div class="text-end">
            <h4 class="text-primary">Grand Total: $<?php echo number_format($total_price, 2); ?></h4>
            <a href="checkout.php" class="btn btn-success">Proceed to Checkout</a>
        </div>
    <?php else: ?>
        <div class="alert alert-info">Your cart is empty!</div>
    <?php endif; ?>
</div>

<?php
include 'footer.php'; // Includes footer and closes any HTML tags
?>
